﻿namespace lottoapplication
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.skandiRadio = new System.Windows.Forms.RadioButton();
            this.hatosRadio = new System.Windows.Forms.RadioButton();
            this.otosRadio = new System.Windows.Forms.RadioButton();
            this.ujtippButton = new System.Windows.Forms.Button();
            this.szamLabel1 = new System.Windows.Forms.Label();
            this.szamLabel3 = new System.Windows.Forms.Label();
            this.szamLabel4 = new System.Windows.Forms.Label();
            this.szamLabel5 = new System.Windows.Forms.Label();
            this.szamLabel2 = new System.Windows.Forms.Label();
            this.szamLabel6 = new System.Windows.Forms.Label();
            this.szamLabel7 = new System.Windows.Forms.Label();
            this.kilepButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.skandiRadio);
            this.groupBox1.Controls.Add(this.hatosRadio);
            this.groupBox1.Controls.Add(this.otosRadio);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox1.Location = new System.Drawing.Point(24, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(223, 257);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sorsolás";
            // 
            // skandiRadio
            // 
            this.skandiRadio.AutoSize = true;
            this.skandiRadio.Location = new System.Drawing.Point(31, 201);
            this.skandiRadio.Name = "skandiRadio";
            this.skandiRadio.Size = new System.Drawing.Size(132, 22);
            this.skandiRadio.TabIndex = 2;
            this.skandiRadio.TabStop = true;
            this.skandiRadio.Text = "Skandináv lottó";
            this.skandiRadio.UseVisualStyleBackColor = true;
            // 
            // hatosRadio
            // 
            this.hatosRadio.AutoSize = true;
            this.hatosRadio.Location = new System.Drawing.Point(31, 130);
            this.hatosRadio.Name = "hatosRadio";
            this.hatosRadio.Size = new System.Drawing.Size(96, 22);
            this.hatosRadio.TabIndex = 1;
            this.hatosRadio.TabStop = true;
            this.hatosRadio.Text = "Hatoslottó";
            this.hatosRadio.UseVisualStyleBackColor = true;
            // 
            // otosRadio
            // 
            this.otosRadio.AutoSize = true;
            this.otosRadio.Location = new System.Drawing.Point(31, 60);
            this.otosRadio.Name = "otosRadio";
            this.otosRadio.Size = new System.Drawing.Size(88, 22);
            this.otosRadio.TabIndex = 0;
            this.otosRadio.TabStop = true;
            this.otosRadio.Text = "Ötöslottó";
            this.otosRadio.UseVisualStyleBackColor = true;
            // 
            // ujtippButton
            // 
            this.ujtippButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ujtippButton.Font = new System.Drawing.Font("Arial", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ujtippButton.Location = new System.Drawing.Point(45, 312);
            this.ujtippButton.Name = "ujtippButton";
            this.ujtippButton.Size = new System.Drawing.Size(175, 40);
            this.ujtippButton.TabIndex = 1;
            this.ujtippButton.Text = "Új tipp";
            this.ujtippButton.UseVisualStyleBackColor = false;
            this.ujtippButton.Click += new System.EventHandler(this.ujtippButton_Click);
            // 
            // szamLabel1
            // 
            this.szamLabel1.BackColor = System.Drawing.Color.Honeydew;
            this.szamLabel1.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.szamLabel1.ForeColor = System.Drawing.Color.Coral;
            this.szamLabel1.Image = ((System.Drawing.Image)(resources.GetObject("szamLabel1.Image")));
            this.szamLabel1.Location = new System.Drawing.Point(249, 146);
            this.szamLabel1.Name = "szamLabel1";
            this.szamLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.szamLabel1.Size = new System.Drawing.Size(96, 88);
            this.szamLabel1.TabIndex = 2;
            this.szamLabel1.Text = "1";
            this.szamLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // szamLabel3
            // 
            this.szamLabel3.BackColor = System.Drawing.Color.Honeydew;
            this.szamLabel3.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.szamLabel3.ForeColor = System.Drawing.Color.Coral;
            this.szamLabel3.Image = ((System.Drawing.Image)(resources.GetObject("szamLabel3.Image")));
            this.szamLabel3.Location = new System.Drawing.Point(456, 146);
            this.szamLabel3.Name = "szamLabel3";
            this.szamLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.szamLabel3.Size = new System.Drawing.Size(96, 88);
            this.szamLabel3.TabIndex = 4;
            this.szamLabel3.Text = "3";
            this.szamLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // szamLabel4
            // 
            this.szamLabel4.BackColor = System.Drawing.Color.Honeydew;
            this.szamLabel4.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.szamLabel4.ForeColor = System.Drawing.Color.Coral;
            this.szamLabel4.Image = ((System.Drawing.Image)(resources.GetObject("szamLabel4.Image")));
            this.szamLabel4.Location = new System.Drawing.Point(558, 146);
            this.szamLabel4.Name = "szamLabel4";
            this.szamLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.szamLabel4.Size = new System.Drawing.Size(96, 88);
            this.szamLabel4.TabIndex = 5;
            this.szamLabel4.Text = "4";
            this.szamLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // szamLabel5
            // 
            this.szamLabel5.BackColor = System.Drawing.Color.Honeydew;
            this.szamLabel5.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.szamLabel5.ForeColor = System.Drawing.Color.Coral;
            this.szamLabel5.Image = ((System.Drawing.Image)(resources.GetObject("szamLabel5.Image")));
            this.szamLabel5.Location = new System.Drawing.Point(660, 146);
            this.szamLabel5.Name = "szamLabel5";
            this.szamLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.szamLabel5.Size = new System.Drawing.Size(96, 88);
            this.szamLabel5.TabIndex = 6;
            this.szamLabel5.Text = "5";
            this.szamLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // szamLabel2
            // 
            this.szamLabel2.BackColor = System.Drawing.Color.Honeydew;
            this.szamLabel2.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.szamLabel2.ForeColor = System.Drawing.Color.Coral;
            this.szamLabel2.Image = ((System.Drawing.Image)(resources.GetObject("szamLabel2.Image")));
            this.szamLabel2.Location = new System.Drawing.Point(351, 146);
            this.szamLabel2.Name = "szamLabel2";
            this.szamLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.szamLabel2.Size = new System.Drawing.Size(96, 88);
            this.szamLabel2.TabIndex = 7;
            this.szamLabel2.Text = "2";
            this.szamLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // szamLabel6
            // 
            this.szamLabel6.BackColor = System.Drawing.Color.Honeydew;
            this.szamLabel6.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.szamLabel6.ForeColor = System.Drawing.Color.Coral;
            this.szamLabel6.Image = ((System.Drawing.Image)(resources.GetObject("szamLabel6.Image")));
            this.szamLabel6.Location = new System.Drawing.Point(762, 146);
            this.szamLabel6.Name = "szamLabel6";
            this.szamLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.szamLabel6.Size = new System.Drawing.Size(96, 88);
            this.szamLabel6.TabIndex = 8;
            this.szamLabel6.Text = "6";
            this.szamLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // szamLabel7
            // 
            this.szamLabel7.BackColor = System.Drawing.Color.Honeydew;
            this.szamLabel7.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.szamLabel7.ForeColor = System.Drawing.Color.Coral;
            this.szamLabel7.Image = ((System.Drawing.Image)(resources.GetObject("szamLabel7.Image")));
            this.szamLabel7.Location = new System.Drawing.Point(864, 146);
            this.szamLabel7.Name = "szamLabel7";
            this.szamLabel7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.szamLabel7.Size = new System.Drawing.Size(96, 88);
            this.szamLabel7.TabIndex = 9;
            this.szamLabel7.Text = "7";
            this.szamLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // kilepButton
            // 
            this.kilepButton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.kilepButton.Font = new System.Drawing.Font("Arial", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kilepButton.Location = new System.Drawing.Point(45, 408);
            this.kilepButton.Name = "kilepButton";
            this.kilepButton.Size = new System.Drawing.Size(175, 40);
            this.kilepButton.TabIndex = 10;
            this.kilepButton.Text = "Kilépés";
            this.kilepButton.UseVisualStyleBackColor = false;
            this.kilepButton.Click += new System.EventHandler(this.kilepButton_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(958, 450);
            this.Controls.Add(this.kilepButton);
            this.Controls.Add(this.szamLabel7);
            this.Controls.Add(this.szamLabel6);
            this.Controls.Add(this.szamLabel2);
            this.Controls.Add(this.szamLabel5);
            this.Controls.Add(this.szamLabel4);
            this.Controls.Add(this.szamLabel3);
            this.Controls.Add(this.szamLabel1);
            this.Controls.Add(this.ujtippButton);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tippek";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton skandiRadio;
        private System.Windows.Forms.RadioButton hatosRadio;
        private System.Windows.Forms.RadioButton otosRadio;
        private System.Windows.Forms.Button ujtippButton;
        private System.Windows.Forms.Label szamLabel1;
        private System.Windows.Forms.Label szamLabel3;
        private System.Windows.Forms.Label szamLabel4;
        private System.Windows.Forms.Label szamLabel5;
        private System.Windows.Forms.Label szamLabel2;
        private System.Windows.Forms.Label szamLabel6;
        private System.Windows.Forms.Label szamLabel7;
        private System.Windows.Forms.Button kilepButton;
    }
}