﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lottoapplication
{
    public partial class Form2 : Form
    {
        Label[] labelarray;
        

        public Form2()
        {
            InitializeComponent();

            labelarray = new Label[] { szamLabel1, szamLabel2, szamLabel3, szamLabel4, szamLabel5, szamLabel6, szamLabel7};
           
            labelekTorles();

            szamLabel1.Visible = false;
            szamLabel2.Visible = false;
            szamLabel3.Visible = false;
            szamLabel4.Visible = false;
            szamLabel5.Visible = false;
            szamLabel6.Visible = false;
            szamLabel7.Visible = false;
        }
                                        
        private void ujtippButton_Click(object sender, EventArgs e)
        {

            if (otosRadio.Checked == true)
            {
                //int[] otos = new int[5];
                Random rnd = new Random();

                for (int i = 0; i < 5; i++) 
                {
                    labelarray[i].Text = rnd.Next(1, 91).ToString();

                    szamLabel1.Visible = true;
                    szamLabel2.Visible = true;
                    szamLabel3.Visible = true;
                    szamLabel4.Visible = true;
                    szamLabel5.Visible = true;
                    szamLabel6.Visible = false;
                    szamLabel7.Visible = false;
                }
                
              /*  int[] otosSzamok = new int[5];
                                
                Random rnd = new Random();

                bool mehet = true;

                for (int i = 0; i < otosSzamok.Count(); i++)
                {
                    int sorsolo = 0;
                    int j = 0;
                    mehet = true;

                    while (j < i && mehet == true) 
                    {
                        if (otosSzamok[j] == sorsolo)
                        {
                            mehet = false;
                        }
                        else 
                        {
                            mehet = true;
                            j++;
                        }

                        if (mehet == true)
                        {
                            otosSzamok[i] = sorsolo;
                        }
                        else 
                        {
                            i--;
                        }
                        

                    }
                    

                    szamLabel1.Visible = true;
                    szamLabel2.Visible = true;
                    szamLabel3.Visible = true;
                    szamLabel4.Visible = true;
                    szamLabel5.Visible = true;
                    szamLabel6.Visible = false;
                    szamLabel7.Visible = false;

                }*/

                
            }



            if (hatosRadio.Checked == true) 
            {
                //int[] hatos = new int[6];
                Random rnd = new Random();

                for (int i = 0; i < 6; i++) 
                {
                    labelarray[i].Text = rnd.Next(1, 46).ToString();


                    szamLabel1.Visible = true;
                    szamLabel2.Visible = true;
                    szamLabel3.Visible = true;
                    szamLabel4.Visible = true;
                    szamLabel5.Visible = true;
                    szamLabel6.Visible = true;
                    szamLabel7.Visible = false;
                }
            }

            if (skandiRadio.Checked == true) 
            {
                //int[] skandi = new int[7];
                Random rnd = new Random();

                for (int i = 0; i < 7; i++) 
                {
                    labelarray[i].Text = rnd.Next(1, 36).ToString();

                    szamLabel1.Visible = true;
                    szamLabel2.Visible = true;
                    szamLabel3.Visible = true;
                    szamLabel4.Visible = true;
                    szamLabel5.Visible = true;
                    szamLabel6.Visible = true;
                    szamLabel7.Visible = true;
                }
            }
 
        }

        private void labelekTorles()
        {
            for (int i = 0; i < 7; i++) 
            {
                labelarray[i].Text = string.Empty;
            }
            

        }

        private void kilepButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
